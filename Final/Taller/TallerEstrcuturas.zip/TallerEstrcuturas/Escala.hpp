/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Escala.hpp
 * Author: Binny
 *
 * Created on 1 de julio de 2025, 19:39
 */

#ifndef ESCALA_HPP
#define ESCALA_HPP

struct Escala{
    int anho;
    int ciclo;
    char escala;
    double valorCred;
    
};

#endif /* ESCALA_HPP */

