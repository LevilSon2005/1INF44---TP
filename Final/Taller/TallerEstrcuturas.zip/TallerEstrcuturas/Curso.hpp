/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Curso.hpp
 * Author: Binny
 *
 * Created on 1 de julio de 2025, 19:39
 */

#ifndef CURSO_HPP
#define CURSO_HPP

struct Curso{
    int codCurso;
    char* nombre;
    double creditos;
};

#endif /* CURSO_HPP */

