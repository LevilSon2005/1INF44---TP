/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.h to edit this template
 */

/* 
 * File:   Funciones.h
 * Author: piero
 *
 * Created on 5 de julio de 2025, 06:28 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

#include "Utils.h"
#include "Plato.h"
#include "Palabra.h"
#include "Atencion.h"

void leerLexicon(const char* nom, Palabra *lexicon);
void leerPlatos(const char* nom, Plato *&platos);
void leerAtenciones(const char* nom, Plato *platos, Atencion *atenciones);
int buscarPlato(Plato *platos, char * cad);
void leerComentarios(const char* nom, Atencion *atenciones, Palabra *lexicon);
int buscarAtencion(Atencion *atenciones, int codigo);
void preprocesado(char *&cadena);
int buscarLexicon(char *cad, Palabra *lexicon);
int procesado(Comentario &com, Palabra *lexicon);
void imprimirReporte(const char* nom, Atencion *atenciones);
int calcularPolaridad(Atencion &atencion);

#endif /* FUNCIONES_H */
