/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Utils.h
 * Author: piero
 *
 * Created on 5 de julio de 2025, 06:30 PM
 */

#ifndef UTILS_H
#define UTILS_H

#include <cstring>
#include <iostream>
#include <fstream>
#include <iomanip>
#define NO_ENCONTRADO -1
        using namespace std;

#endif /* UTILS_H */

