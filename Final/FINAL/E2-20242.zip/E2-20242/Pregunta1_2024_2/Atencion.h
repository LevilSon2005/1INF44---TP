/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Atencion.h
 * Author: piero
 *
 * Created on 5 de julio de 2025, 06:26 PM
 */

#ifndef ATENCION_H
#define ATENCION_H

#include "Plato.h"
#include "Comentario.h"

struct Atencion{
    int codigo;
    Plato *platos_atendidos;
    int cantidad_platos;
    double total_venta;
    int hora;
    Comentario *comentarios;
    int cantidad_comentarios;
};

#endif /* ATENCION_H */

