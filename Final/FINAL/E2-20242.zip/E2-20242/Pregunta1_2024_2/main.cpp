/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: piero
 *
 * Created on 5 de julio de 2025, 06:21 PM
 */

#include <cstdlib>

#include "Palabra.h"
#include "Funciones.h"
#include "Atencion.h"
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    Palabra lexicon[100];
    Plato *platos;
    Atencion atenciones[100];
    leerLexicon("lexicon.csv", lexicon);
    leerPlatos("platos.csv", platos);
    leerAtenciones("atenciones.txt", platos, atenciones);
    leerComentarios("comentarios.csv", atenciones, lexicon);
    imprimirReporte("ReporteAtencionesAnalisisSentimientos.txt", atenciones);
    return 0;
}

