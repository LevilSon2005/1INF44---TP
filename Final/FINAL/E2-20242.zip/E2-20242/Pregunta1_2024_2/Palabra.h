/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Palabra.h
 * Author: piero
 *
 * Created on 5 de julio de 2025, 06:22 PM
 */

#ifndef PALABRA_H
#define PALABRA_H

struct Palabra{
    int polaridad;
    char * texto;
};

#endif /* PALABRA_H */

