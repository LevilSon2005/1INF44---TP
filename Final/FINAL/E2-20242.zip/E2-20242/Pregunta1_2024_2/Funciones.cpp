/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.cc to edit this template
 */

/* 
 * File:   Funciones.cpp
 * Author: piero
 * 
 * Created on 5 de julio de 2025, 06:28 PM
 */

#include "Funciones.h"

char* leerCadena(ifstream &arch, int tam, char c){
    char buff[500], *cad;
    arch.get(buff, tam, c);
    if(arch.eof()) return nullptr;
    arch.get();
    cad = new char[strlen(buff)+1];
    strcpy(cad, buff);
    return cad;
}

void leerLexicon(const char* nom, Palabra *lexicon){
    ifstream arch(nom, ios::in);
    if(not arch.is_open()){
        cout << "ERROR AL ABRIR EL ARCHIVO " << nom;
        exit(1);
    }
    int polaridad, i=0;
    while(true){
        lexicon[i].texto = leerCadena(arch, 100, ',');
        if(lexicon[i].texto == nullptr) break;
        arch >> polaridad;
        arch.get();
        lexicon[i].polaridad = polaridad;
        i++;
    }
}

void leerPlatos(const char* nom, Plato *&platos){
    ifstream arch(nom, ios::in);
    if(not arch.is_open()){
        cout << "ERROR AL ABRIR EL ARCHIVO " << nom;
        exit(1);
    }
    platos = new Plato[200];
    int i=0;
    while(true){
        platos[i].codigo = leerCadena(arch, 10, ',');
        if(platos[i].codigo == nullptr) break;
        platos[i].nombre = leerCadena(arch, 100, ',');
        arch >> platos[i].precio;
        arch.get();
        i++;
    }
}

void leerAtenciones(const char* nom, Plato *platos, Atencion *atenciones){
    ifstream arch(nom, ios::in);
    if(not arch.is_open()){
        cout << "ERROR AL ABRIR EL ARCHIVO " << nom;
        exit(1);
    }
    char *cadena, c;
    int i=0, hora, minuto, cantidad, indice_plato=0;
    while(true){
        arch >> atenciones[i].codigo;
        if(arch.eof()){
            atenciones[i].codigo = -1;
            break;
        }
        arch >> hora >> c >> minuto;
        atenciones[i].hora = hora *100 + minuto; // 22:36 -> 2236
        arch >> ws;
        atenciones[i].cantidad_platos = 0;
        atenciones[i].platos_atendidos = new Plato[20];
        atenciones[i].comentarios = new Comentario[20];
        atenciones[i].cantidad_comentarios = 0;
        while(true){
            cadena = leerCadena(arch, 10, ' ');
            arch >> cantidad;
            indice_plato = buscarPlato(platos, cadena);
            if(indice_plato != NO_ENCONTRADO) {
                atenciones[i].platos_atendidos[atenciones[i].cantidad_platos] = platos[indice_plato];
                atenciones[i].platos_atendidos[atenciones[i].cantidad_platos].cantidad = cantidad;
                atenciones[i].cantidad_platos++;
            }
            if(arch.get() == '\n') break;
            arch >> ws;
        }
        i++;
    }
}

int buscarPlato(Plato *platos, char * cad){
    for(int i=0; platos[i].codigo != nullptr; i++){
        if(strcmp(platos[i].codigo, cad) == 0) return i;
    }
    return NO_ENCONTRADO;
}

void leerComentarios(const char* nom, Atencion *atenciones, Palabra *lexicon){
    ifstream arch(nom, ios::in);
    if(not arch.is_open()){
        cout << "ERROR AL ABRIR EL ARCHIVO " << nom;
        exit(1);
    }
    char *cad;
    int codigo, indice, polaridad;
    while(true){
        arch >> codigo;
        if(arch.eof()) break;
        arch.get();
        indice = buscarAtencion(atenciones, codigo);
        if(indice != NO_ENCONTRADO){
            atenciones[indice].comentarios[atenciones[indice].cantidad_comentarios].pre_procesado = leerCadena(arch, 500, '\n');
            preprocesado(atenciones[indice].comentarios[atenciones[indice].cantidad_comentarios].pre_procesado);
            procesado(atenciones[indice].comentarios[atenciones[indice].cantidad_comentarios], lexicon);
            atenciones[indice].cantidad_comentarios++;            
        } else while(arch.get() != '\n');
    }
}

int buscarAtencion(Atencion *atenciones, int codigo){
    for(int i=0; atenciones[i].codigo != -1; i++){
        if(atenciones[i].codigo == codigo) return i;
    }
    return NO_ENCONTRADO;
}

void preprocesado(char *&cadena){
    int k=0;
    char *procesado=new char[strlen(cadena)+1]{}, c;
    for(int i=0; cadena[i]; i++){
        c = cadena[i];
        if(isalpha(c) or c == ' '){
            procesado[k] = tolower(c);
            k++;
        }
    }
    cadena = procesado;
}

int procesado(Comentario &com, Palabra *lexicon){
    int polaridad = 0, cant=0, counter=0;
    char buff[500]{}, c;
    for(int i=0; com.pre_procesado[i]; i++){
        c = com.pre_procesado[i];
        if(c != ' ') {
            buff[counter] = c;
            buff[counter+1] = '\0';
            counter++;
        }
        else{
            com.palabras[cant].texto = new char[strlen(buff)+1];
            strcpy(com.palabras[cant].texto, buff);
            com.palabras[cant].polaridad = buscarLexicon(com.palabras[cant].texto, lexicon);
            polaridad += com.palabras[cant].polaridad;
            counter = 0;
            cant++;
        }
    }
    com.polaridad_total = polaridad;
    com.cantidad_palabras = cant;
}

int buscarLexicon(char *cad, Palabra *lexicon){
    for(int i=0; lexicon[i].texto != nullptr; i++){
        if(strcmp(cad, lexicon[i].texto) == 0) return lexicon[i].polaridad;
    }
    return 0;
}

void imprimirReporte(const char* nom, Atencion *atenciones){
    ofstream arch(nom, ios::out);
    if(not arch.is_open()){
        cout << "ERROR AL ABRIR EL ARCHIVO " << nom;
        exit(1);
    }
    for(int i=0; atenciones[i].codigo != -1; i++){
        arch << "N° ATENCION " << atenciones[i].codigo << setw(40) << "Atendido a las "
             << setfill('0') << setw(2) << atenciones[i].hora/100 << ":" << setw(2)
             << atenciones[i].hora%100 << setfill(' ') << endl;
        arch << setfill('-') << setw(77) << ' ' << setfill(' ') << endl;
        for(int j=0; j < atenciones[i].cantidad_platos; j++){
            arch << atenciones[i].platos_atendidos[j].codigo << ")  " << atenciones[i].platos_atendidos[j].nombre
                 << setw(40-strlen(atenciones[i].platos_atendidos[j].nombre)) << atenciones[i].platos_atendidos[j].precio << setw(5) << " "
                 << atenciones[i].platos_atendidos[j].precio * atenciones[i].platos_atendidos[j].cantidad << endl;
        }
        arch << "Polaridad total de los comentarios: " << calcularPolaridad(atenciones[i]) << endl;
        arch << setfill('=') << setw(77) << ' ' << setfill(' ') << endl;
    }
}

int calcularPolaridad(Atencion &atencion){
    int polaridad=0;
    for(int i=0; i < atencion.cantidad_comentarios; i++){
        polaridad += atencion.comentarios[i].polaridad_total;
    }
    return polaridad;
}