/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Plato.hpp
 * Author: Binny
 *
 * Created on 5 de julio de 2025, 18:25
 */

#ifndef PLATO_HPP
#define PLATO_HPP

struct Plato{
    char* codigo;
    char* nombre;
    int cantidad; //
    double precio;
};

#endif /* PLATO_HPP */

