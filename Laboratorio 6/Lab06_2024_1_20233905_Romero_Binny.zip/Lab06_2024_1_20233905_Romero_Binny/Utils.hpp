/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Utils.hpp
 * Author: Binny
 *
 * Created on 29 de mayo de 2025, 11:55
 */

#ifndef UTILS_HPP
#define UTILS_HPP

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>

using namespace std;

#define NO_ENCONTRADO -1
#define MAXALUMNOS 80
#define MAXFACULTADES 10
#define MAXNOMBRE 80
#define TAMREPORTE 160
#define COLUMNAS 6
#endif /* UTILS_HPP */

