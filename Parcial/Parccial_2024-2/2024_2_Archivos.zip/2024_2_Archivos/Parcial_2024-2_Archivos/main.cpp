/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: binny
 *
 * Created on 18 de mayo de 2025, 22:52
 */

#include "funciones.hpp"
int main(int argc, char** argv) {

    procesar_reporte("Alumnos.txt","Cursos.txt","Escalas.txt","Matricula.txt","reporte.txt");
    
    return 0;
}

