/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   utils.hpp
 * Author: Binny
 *
 * Created on 18 de mayo de 2025, 22:52
 */

#ifndef UTILS_HPP
#define UTILS_HPP

#include <iostream>
#include <iomanip>
#include <fstream>

using namespace std;

#define TAMREPORTE 180
#define COLUMNAS 3


#endif /* UTILS_HPP */

