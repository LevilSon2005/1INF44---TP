/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.h to edit this template
 */

/* 
 * File:   funciones.hpp
 * Author: aml
 *
 * Created on 25 de abril de 2025, 09:44 AM
 */

#ifndef FUNCIONES_HPP
#define FUNCIONES_HPP
#include "Utils.hpp"

void leer_procesar_canales(const char* name_arch_canales, const char* name_arch_registro, const char* name_arch_televidentes, const char* name_arch_reporte);

#endif /* FUNCIONES_HPP */
