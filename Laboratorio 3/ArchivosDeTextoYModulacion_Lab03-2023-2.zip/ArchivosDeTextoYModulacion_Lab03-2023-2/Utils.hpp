/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Utils.hpp
 * Author: aml
 *
 * Created on 25 de abril de 2025, 09:43 AM
 */

#ifndef UTILS_HPP
#define UTILS_HPP

#include <iostream>
#include <iomanip>
#include <fstream>

using namespace std;

#define TAMMAX 180
#define COLUMNAS 7
#define TITULO1 37
#define TITULO2 37
#define TITULO3 11
#define TITULO4 68


#endif /* UTILS_HPP */

